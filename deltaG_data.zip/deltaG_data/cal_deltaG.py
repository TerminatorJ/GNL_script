#-*- encoding:utf8-*-
import pickle
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/ciona.pickle","rb") as f1:
    with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/Doench_V1.pickle","rb") as f2:
        with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/Doench_V2.pickle","rb") as f3:
            with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/Drosophila.pickle","rb") as f4:
                with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/hct116_1.pickle","rb") as f5:
                    with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/hek293t.pickle","rb") as f6:
                        with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/hela.pickle","rb") as f7:
                            with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/hl60.pickle","rb") as f8:
                                with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/MEsc.pickle","rb") as f9:
                                    with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/z_fish_GZ.pickle","rb") as f10:
                                        with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/z_fish_MM.pickle","rb") as f11:
                                            with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/z_fish_VZ.pickle","rb") as f12:
                                             

                                                    ciona_data=pickle.load(f1)
                                                    Doench_V1_data=pickle.load(f2)
                                                    Doench_V2_data=pickle.load(f3)
                                                    Drosophila_data=pickle.load(f4)
                                                    MEsc_data=pickle.load(f9)
                                                    hct116_1_data=pickle.load(f5)
                                                    hek293t_data=pickle.load(f6)
                                                    hela_data=pickle.load(f7)
                                                    hl60_data=pickle.load(f8)
                                                    z_fish_GZ=pickle.load(f10)
                                                    z_fish_MM=pickle.load(f11)
                                                    z_fish_VZ=pickle.load(f12)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/all_save_data/13no_normalize/elegans.pickle","rb") as f13:
    elegans_data=pickle.load(f13)












#print(ciona_data)
def cal_deltaG(dataname):
    dict={"ciona":ciona_data,
        "Doench_V1":Doench_V1_data,
        "Doench_V2":Doench_V2_data,
        "Drosophila":Drosophila_data,
        "hct116_1":hct116_1_data,
        "hek293t":hek293t_data,
        "hela":hela_data,
        "hl60":hl60_data,
        "MEsc":MEsc_data,
        "z_fish_GZ":z_fish_GZ,
        "z_fish_MM":z_fish_MM,
        "elegans":elegans_data,
        "z_fish_VZ":z_fish_VZ}
    dataset_20mer=dict[dataname]["30mer"].apply(lambda x : x[4:24])
    list=[]
    for i in dataset_20mer.values:
        list.append(i)
    with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/deltaG_data/%s.txt" % dataname,"w") as f14:
        f14.write(";".join(list))

cal_deltaG("ciona")
cal_deltaG("Doench_V1")
cal_deltaG("Doench_V2")
cal_deltaG("Drosophila")
cal_deltaG("hct116_1")
cal_deltaG("hek293t")
cal_deltaG("hela")
cal_deltaG("hl60")
cal_deltaG("MEsc")
cal_deltaG("z_fish_GZ")
cal_deltaG("z_fish_MM")
cal_deltaG("z_fish_VZ")
cal_deltaG("elegans")



















