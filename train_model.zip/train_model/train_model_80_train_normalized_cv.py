# -*- coding:utf-8 -*-
import pandas as pd
import pandas
import numpy as np
import scipy.stats as st
import scipy as sp
import copy
from sklearn.preprocessing import MinMaxScaler
import sklearn
from sklearn.linear_model import ARDRegression, LinearRegression
from sklearn.metrics import roc_curve, auc
import sklearn.linear_model
from sklearn.grid_search import GridSearchCV
import sklearn.ensemble as en
import scipy.stats as st
from sklearn.model_selection import cross_val_score
from sklearn import svm
import os
import sys
import pickle
import multiprocessing
from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split
from sklearn import tree
from sklearn import linear_model
import time
import Bio.SeqUtils as SeqUtil
import Bio.Seq as Seq
import Bio.SeqUtils.MeltingTemp as Tm	
import pickle
import itertools
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.neural_network import MLPRegressor
t1 = time.time()
from sklearn.model_selection import KFold

#import the input and y for training
input_list=["/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/ciona_input_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Doench_V1_input_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Doench_V2_input_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Drosophila_input_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hct116_1_input_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hek293t_input_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hela_input_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_GZ_input_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_MM_input_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_VZ_input_80.pickle"]




y_list=["/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/ciona_y_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Doench_V1_y_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Doench_V2_y_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Drosophila_y_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hct116_1_y_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hek293t_y_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hela_y_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_GZ_y_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_MM_y_80.pickle","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_VZ_y_80.pickle"]
name_dict={"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/ciona_input_80.pickle":"ciona","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Doench_V1_input_80.pickle":"Doench_V1","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Doench_V2_input_80.pickle":"Doench_V2","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Drosophila_input_80.pickle":"Drosophila","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hct116_1_input_80.pickle":"hct116_1","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hek293t_input_80.pickle":"hek293t","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hela_input_80.pickle":"hela","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_GZ_input_80.pickle":"z_fish_GZ","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_MM_input_80.pickle":"z_fish_MM","/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_VZ_input_80.pickle":"z_fish_VZ"}








#model train
def spearmanr(x,y):
    r, p = st.spearmanr(x, y)
    return r, p

def spearman_scoring(clf,X, y):
    y_pred = clf.predict(X)
    return sp.stats.spearmanr(y_pred, y)[0]
def extract_spearman_for_fold_deep(metrics,test, y_pred):
    spearman=spearmanr(test, y_pred)[0]
#     assert not np.isnan(spearman), "found nan spearman"
    metrics.append(spearman)
def extract_fpr_tpr_for_fold(aucs,y_binary, test, y_pred):
    assert len(np.unique(y_binary))<=2, "if using AUC need binary targets"
    fpr, tpr, _ = roc_curve(y_binary[test], y_pred)
    roc_auc = auc(fpr, tpr)
    aucs.append(roc_auc)
def get_train_test(x_deep,y_deep,state=0):
    x_deep_train,x_deep_test,y_deep_train,y_deep_test=train_test_split(x_deep,y_deep,random_state=state)
    return x_deep_train,x_deep_test,y_deep_train,y_deep_test
def select_model(x_deep,y_deep,model,state,save_name_tail):
#    x_deep_train=get_train_test(x_deep,y_deep,state)[0]
#    y_deep_train=get_train_test(x_deep,y_deep,state)[2]
#    x_deep_test=get_train_test(x_deep,y_deep,state)[1]
#    y_deep_test=get_train_test(x_deep,y_deep,state)[3]
    


    if model== "Ada":
        print("Adaboost with KFold")
        param_grid = {'learning_rate': [0.1, 0.05, 0.01]}
        n_folds=10
       # cv = sklearn.cross_validation.KFold(x_deep.shape[0], n_folds=n_folds, shuffle=True)#创建随机打乱的index
        metrics=[]
       # est = en.GradientBoostingRegressor()
        print("doing the GridSearchCV")
       # clf_1 = GridSearchCV(est, param_grid, n_jobs=-1, verbose=1, cv=cv, scoring=spearman_scoring, iid=False)##需要调参
        
#        with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_Ada_model.pickle" % save_name_tail,"wb") as f2:
#            pickle.dump(clf,f2)
        print("after doing the GridSearchCV")
        kf = KFold(n_splits=10)
        
        n=0
        for train,test in kf.split(x_deep):
            n+=1 
            x_train=x_deep[train]
            y_train=y_deep[train]
            x_test=x_deep[test]
            y_test=y_deep[test]
            cv = sklearn.cross_validation.KFold(x_train.shape[0], n_folds=n_folds, shuffle=True)
            est = en.GradientBoostingRegressor()
            clf_1 = GridSearchCV(est, param_grid, n_jobs=-1, verbose=1, cv=cv, scoring=spearman_scoring, iid=False)            


            clf_1.fit(x_train,y_train)
            print("%s best params:" % (save_name_tail)+str(clf_1.best_params_))
            with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_%d_Ada_model_80_normalized.pickle" % (save_name_tail,n),"wb") as f2:
                pickle.dump(clf_1,f2)
                y_pred = clf_1.predict(x_test)
                extract_spearman_for_fold_deep(metrics,y_test,y_pred)
        return metrics
     #   print("after fitting")
    elif model=="DT":
        print("DT With KFold")
        parameters = {"max_depth":(1,2,5,10,100,1000)}
        n_folds=10
        metrics=[]
        print("doing the GridSearchCV")
   #     with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_DT_model.pickle" % save_name_tail,"wb") as f2:
   #         pickle.dump(clf,f2)
        kf = KFold(n_splits=10)
        print("after doing the GridSearchCV")
        n=0
        for train,test in kf.split(x_deep):
            print(train)
            print(test)
            n+=1
            x_train=x_deep[train]
            y_train=y_deep[train]
            x_test=x_deep[test]
            y_test=y_deep[test]
            cv = sklearn.cross_validation.KFold(x_train.shape[0], n_folds=n_folds, shuffle=True)
            DT = tree.DecisionTreeRegressor(random_state=state)
            clf_2 = GridSearchCV(DT, parameters, n_jobs=-1, verbose=1, cv=cv, scoring=spearman_scoring, iid=False)
            clf_2.fit(x_train,y_train)
            
            print("%s best params:" % (save_name_tail)+str(clf_2.best_params_))
            with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_%d_DT_model_80_normalized.pickle" % (save_name_tail,n),"wb") as f2:
                pickle.dump(clf_2,f2)
                print("after fitting")
                y_pred = clf_2.predict(x_test)
                extract_spearman_for_fold_deep(metrics,y_test,y_pred)
        return metrics
       
    elif model=="linear_model":
        print("linear_model With KFold")
        n_folds=10
        metrics=[]
        reg = linear_model.LinearRegression()
#        with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_lm_model.pickle" % save_name_tail,"wb") as f2:
#            pickle.dump(reg,f2)

        n=0
        kf = KFold(n_splits=10)
        for train,test in kf.split(x_deep):
            n+=1
            x_train=x_deep[train]
            y_train=y_deep[train]
            x_test=x_deep[test]
            y_test=y_deep[test]
            reg.fit(x_train,y_train)
            with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_%d_lm_model_80_normalized.pickle" % (save_name_tail,n),"wb") as f2:
                pickle.dump(reg,f2)
                print("after fitting")
                y_pred = reg.predict(x_test)
                extract_spearman_for_fold_deep(metrics,y_test,y_pred)
        return metrics
    elif model=="Ridge":
        print("Ridge With KFold")
        parameters = {"alpha":(1,3,5,7,9,10)}
        n_folds=10
        metrics=[]
        print("doing the GridSearchCV")
 #       with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_Ridge_model.pickle" % save_name_tail,"wb") as f2:
 #           pickle.dump(clf,f2)
        kf = KFold(n_splits=10)
        n=0
        for train,test in kf.split(x_deep):
            n+=1
            x_train=x_deep[train]
            y_train=y_deep[train]
            x_test=x_deep[test]
            y_test=y_deep[test]
            cv = sklearn.cross_validation.KFold(x_train.shape[0], n_folds=n_folds, shuffle=True)
            reg = linear_model.Ridge()
            clf_3 = GridSearchCV(reg, parameters, n_jobs=-1, verbose=1, cv=cv, scoring=spearman_scoring, iid=False)
            clf_3.fit(x_train,y_train)
            print("%s best params:" % (save_name_tail)+str(clf_3.best_params_))
            with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_%d_Ridge_model_80_normalized.pickle" % (save_name_tail,n),"wb") as f2:
                pickle.dump(clf_3,f2)
                print("after fitting")
                y_pred = clf_3.predict(x_test)
                extract_spearman_for_fold_deep(metrics,y_test,y_pred)
        return metrics
    elif model=="Lasso":
        print("Lasso With KFold")
        parameters = {"alpha":(0.1,0.5,0.75,1,10)}
        n_folds=10
        metrics=[]
        print("doing the GridSearchCV")
#        with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_Lasso_model.pickle" % save_name_tail,"wb") as f2:
#            pickle.dump(clf,f2)
        kf = KFold(n_splits=10)
        n=0
        for train,test in kf.split(x_deep):
            n+=1
            x_train=x_deep[train]
            y_train=y_deep[train]
            x_test=x_deep[test]
            y_test=y_deep[test]
            cv = sklearn.cross_validation.KFold(x_train.shape[0], n_folds=n_folds, shuffle=True)
            reg = linear_model.Lasso()
            clf_4 = GridSearchCV(reg, parameters, n_jobs=-1, verbose=1, cv=cv, scoring=spearman_scoring, iid=False)
            clf_4.fit(x_train,y_train)
       	    print("%s best params:" % (save_name_tail)+str(clf_4.best_params_))
            with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_%d_Lasso_model_80_normalized.pickle" % (save_name_tail,n),"wb") as f2:
                pickle.dump(clf_4,f2)
                print("after fitting")
                y_pred = clf_4.predict(x_test)
                extract_spearman_for_fold_deep(metrics,y_test,y_pred)
        return metrics



    elif model=="Bayes Ridge":
        print("Bayes Ridge With KFold")
        metrics=[]
        reg = linear_model.BayesianRidge()
#        with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_BR_model.pickle" % save_name_tail,"wb") as f2:
#            pickle.dump(reg,f2)

        print("doing the GridSearchCV")
        n=0
        kf = KFold(n_splits=10)
        for train,test in kf.split(x_deep):
            n+=1
            x_train=x_deep[train]
            y_train=y_deep[train]
            x_test=x_deep[test]
            y_test=y_deep[test]
            reg.fit(x_train,y_train)
            with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_%d_BR_model_80_normalized.pickle" % (save_name_tail,n),"wb") as f2:
                pickle.dump(reg,f2)
                print("after fitting")
                y_pred = reg.predict(x_test)
                extract_spearman_for_fold_deep(metrics,y_test,y_pred)
        return metrics
    elif model== "RF":
        print("RF With KFold")
        metrics=[]
        rf =RandomForestRegressor()
#        with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_RF_model.pickle" % save_name_tail,"wb") as f2:
#            pickle.dump(rf,f2)
        print("doing the GridSearchCV")
        kf = KFold(n_splits=10)
        n=0
        for train,test in kf.split(x_deep):
            n+=1
            x_train=x_deep[train]
            y_train=y_deep[train]
            x_test=x_deep[test]
            y_test=y_deep[test]
            rf.fit(x_train,y_train)
            with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_%d_RF_model_80_normalized.pickle" % (save_name_tail,n),"wb") as f2:
                pickle.dump(rf,f2)
                print("after fitting")
                y_pred = rf.predict(x_test)
                extract_spearman_for_fold_deep(metrics,y_test,y_pred)
        return metrics
    elif model == "NN":
        print("NN With KFold")
        metrics=[]
        nn=MLPRegressor(hidden_layer_sizes=[100,100],activation="relu",alpha=1.0,solver="lbfgs")
#        with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_NN_model.pickle" % save_name_tail,"wb") as f2:
#            pickle.dump(nn,f2)
        kf = KFold(n_splits=10)
        n=0
        for train,test in kf.split(x_deep):
            n+=1
            x_train=x_deep[train]
            y_train=y_deep[train]
            x_test=x_deep[test]
            y_test=y_deep[test]
            nn.fit(x_train,y_train)
            with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/%s_%d_NN_model_80_normalized.pickle" % (save_name_tail,n),"wb") as f2:
                pickle.dump(nn,f2)
                print("after fitting")
                y_pred = nn.predict(x_test)
                extract_spearman_for_fold_deep(metrics,y_test,y_pred)
        return metrics

'''
##plot the figure   
def plot_model_metrix(model_max_list,matrix_max_list,save_fig_name_tail):
    plt.figure()
    ax = plt.gca()
    for model,matrix in zip(model_max_list,matrix_max_list):
        colors=["#00008B","#D14B5D","#006400","#00BFFF","#D8BFD8","#D14B5D","#FF6347","#40E0D0","#EE82EE","#00008B"]
        try:
            plt.bar(model_max_list.index(model)+1,matrix,width=0.4,color=colors[model_max_list.index(model)],align='center',label=str(model))
        except TypeError:
            print("there exist None type")
    ax.set_xticklabels([" ","Ada","DT","lm","ridge","lasso","br","rf","nn"],fontsize=10)
    plt.title("use 80 percent %s to train the model" % save_fig_name_tail)
    ax.set_ylabel('Spearman r', fontsize=10)
    plt.yticks(fontsize=10)
    plt.ylim((0,1))
    plt.xticks(np.arange(0,10,1))
    plt.savefig("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_fig/%s_model_80_percent.png" % save_fig_name_tail)
'''
#matrix_list=[]
#model_list=[]
for input,y in zip(input_list,y_list):
    name=name_dict[input]  
    with open(input,"rb") as f1:
        this_input=pickle.load(f1)
        with open(y,"rb") as f2:
            matrix_list=[]
            #model_list=[]
            this_y=pickle.load(f2)
            ada_matrix=select_model(this_input,this_y,"Ada",state=0,save_name_tail=name)
            dt_matrix=select_model(this_input,this_y,"DT",state=0,save_name_tail=name)
            lm_matrix=select_model(this_input,this_y,"linear_model",state=0,save_name_tail=name)
            ridge_matrix=select_model(this_input,this_y,"Ridge",state=0,save_name_tail=name)
            lasso_matrix=select_model(this_input,this_y,"Lasso",state=0,save_name_tail=name)
            br_matrix=select_model(this_input,this_y,"Bayes Ridge",state=0,save_name_tail=name)
            rf_matrix=select_model(this_input,this_y,"RF",state=0,save_name_tail=name)
            nn_matrix=select_model(this_input,this_y,"NN",state=0,save_name_tail=name)
            print("%s ada 10 Fold result: %s",(name,ada_matrix))
            print("%s dt  10 Fold result: %s",(name,dt_matrix))
            print("%s lm 10 Fold result: %s",(name,lm_matrix))
            print("%s ridge 10 Fold result: %s",(name,ridge_matrix))
            print("%s lasso 10 Fold result: %s",(name,lasso_matrix))
            print("%s br 10 Fold result: %s",(name,br_matrix))
            print("%s rf 10 Fold result: %s",(name,rf_matrix))
            print("%s nn 10 Fold result: %s",(name,nn_matrix))
'''
                matrix_list.append(ada_matrix)
                matrix_list.append(dt_matrix)
                matrix_list.append(lm_matrix)
                matrix_list.append(ridge_matrix)
                matrix_list.append(lasso_matrix)
                matrix_list.append(br_matrix)
                matrix_list.append(rf_matrix)
                matrix_list.append(nn_matrix)
                print(str(matrix_list)+"\n")
               # model_list=["max_ada","max_dt","max_lm","max_ridge","max_lasso","max_br","max_rf","max_nn"]
               # plot_model_metrix(model_list,matrix_list,save_fig_name_tail=name)
'''

t2 = time.time()
print ("\t\tElapsed time for max train and plot is %.2f seconds" % (t2-t1))







