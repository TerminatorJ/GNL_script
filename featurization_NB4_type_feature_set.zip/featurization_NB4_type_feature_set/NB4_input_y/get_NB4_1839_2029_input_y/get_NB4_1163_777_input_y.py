import pickle
import numpy as np
def get_ranked_feature_list(mrmr_file_path):
    with open(mrmr_file_path,"r") as f1:
        need_range=f1.read().split("*** mRMR features ***")[1].split("\n")
        need_range.remove(" ")
#         print(need_range)
        name=[column.strip() for column in need_range[0].split("\t")]
        feature_list=[]
        release=""

        for item in need_range[1:-11]:
#             print(item)
            try:
                feature_name=item.split("\t")[2].strip()
                order=item.split("\t")[0]
                feature_list.append(feature_name)
            except IndexError:
                continue
#                 order=item.split("\t")[0]
#                 print(need_range[int(order.strip())])
#             feature_list.append(feature_name)
        return feature_list
# "C:\\Users\\23008\\CRISPRarray\\IFS\\result_of_Doench_add_diso_mrmr.txt"
#print(feature_list)



feature_list_hela=get_ranked_feature_list("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/result_of_mrmr/result_of_mrmr_add_no_epi_pssm_diso_feat_for_hela.txt")
feature_list_hct116_hela=get_ranked_feature_list("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/result_of_mrmr/result_of_mrmr_add_no_epi_pssm_diso_feat_for_hct116_hela.txt")
print(len(feature_list_hct116_hela))

with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/IFS_script/no_dup_columns_X_y/hela_X_epi_pssm_diso.pickle","rb") as f2:
    hela_X=pickle.load(f2)

with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/IFS_script/no_dup_columns_X_y/hct116_1_hela_add_epi_pssm_diso_no_dup.pickle","rb") as f3:
    hct116_hela_X=pickle.load(f3)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_2701_X.pickle","rb") as f4:
    NB4_2701_X=pickle.load(f4)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_2488_X.pickle","rb") as f5:
    NB4_2488_X=pickle.load(f5)
#print(NB4_2488_X["A_4pssm"])
NB4_used_columns_1163_X=NB4_2488_X[feature_list_hct116_hela[0:1163]]
NB4_used_columns_1163_input=np.array(NB4_used_columns_1163_X)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_1163_X.pickle","wb") as f6:
    pickle.dump(NB4_used_columns_1163_X,f6)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_1163_input","wb") as f7:
    pickle.dump(NB4_used_columns_1163_input,f7)


NB4_used_columns_777_X=NB4_2701_X[feature_list_hela[0:777]]
NB4_used_columns_777_input=np.array(NB4_used_columns_777_X)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_777_X.pickle","wb") as f8:
    pickle.dump(NB4_used_columns_777_X,f8)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_777_input","wb") as f9:
    pickle.dump(NB4_used_columns_777_input,f9)

