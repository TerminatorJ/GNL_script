# -*- coding:utf-8 -*-
import pandas as pd
import pandas
import numpy as np
import scipy.stats as st
import scipy as sp
import copy
from sklearn.preprocessing import MinMaxScaler
import sklearn
from sklearn.linear_model import ARDRegression, LinearRegression
from sklearn.metrics import roc_curve, auc
import sklearn.linear_model
from sklearn.grid_search import GridSearchCV
import sklearn.ensemble as en
import scipy.stats as st
from sklearn.model_selection import cross_val_score
from sklearn import svm
import os
import sys
import pickle
import multiprocessing
from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split
from sklearn import tree
from sklearn import linear_model
import time
import Bio.SeqUtils as SeqUtil
import Bio.Seq as Seq
import Bio.SeqUtils.MeltingTemp as Tm	
import pickle
import itertools
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.neural_network import MLPRegressor
t1 = time.time()

with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_dataset/NB4.pickle","rb") as f1:
    NB4_data=pickle.load(f1)






#提取特征
def get_alphabet(order,raw_alphabet=["A","G","C","T"]):##返回两个碱基的所有排列组合
    alphabet=["".join(i) for i in itertools.product(raw_alphabet,repeat=order)]
    return alphabet
def genera_nucleotide_features(s,order,prefix="",feature_type="all",raw_alphabet=["A","T","G","C"]):##将有位置的和没有位置的二核苷酸特征都列出来
    alphabet=get_alphabet(order,raw_alphabet=raw_alphabet)
    features_pos_dependent=np.zeros(len(alphabet)*(len(s)-(order-1)))
    features_pos_independent=np.zeros(np.power(len(raw_alphabet),order))
    index_dependent=[]
    index_independent=[]
    for position in range(0,(len(s)-order+1),1):
        for i in alphabet:
            index_dependent.append("%s%s_%s" % (prefix,i,position))
    for i in alphabet:
        index_independent.append("%s%s" % (prefix,i))
    for position in range(0,(len(s)-order+1),1):
        nucl=s[position:position+order]
        features_pos_dependent[alphabet.index(nucl)+(position*len(alphabet))]=1.0
        features_pos_independent[alphabet.index(nucl)]+=1.0
    if feature_type=="all" or feature_type=="pos_independent":
        if feature_type=="all":
            res=pd.Series(features_pos_dependent,index=index_dependent),pd.Series(features_pos_independent,index=index_independent)
            return res
        else:
            res=pd.Series(features_pos_independent,index=index_independent)
            return res
    res=pd.Series(features_pos_dependent,index=index_dependent)#没有特殊情况下返回的是位置依赖的一个Series
    return res
def nucleotide_features_dictionary(prefix=""):
    seqname=["-4","-3","-2","-1"]
    seqname.extend([str(i) for i in range(1,21)])#在序列前面加了4个碱基，后面加了三个碱基
    seqname.extend(["N","G","G","+1","+2","+3"])
    orders=[1,2,3]
    sequence_len=30
    feature_names_dep=[]
    feature_names_indep=[]
    index_dependent=[]
    index_independent=[]
    for  order in orders:
        raw_alphabet=["A","G","C","T"]
        alphabet=["".join(i)for i in itertools.product(raw_alphabet,repeat=order)]
        feature_pos_dependent=np.zeros(len(alphabet)*(sequence_len-order+1))
        feature_pos_independent=np.zeros(np.power(len(raw_alphabet),order))
        index_dependent.extend(["%s_pd.Order%s_P%d" % (prefix,order,i) for i in range(len(feature_pos_dependent))])
        index_independent.extend(["%s_pi.Order%s_P%d" % (prefix,order,i) for i in range(len(feature_pos_independent))])
        for pos in range(sequence_len-(order-1)) :
            for letter in alphabet:
                feature_names_dep.append("%s_%s" % (letter,seqname[pos]))
        for letter in alphabet:
            feature_names_indep.append("%s" % letter)
    index_all=index_dependent+index_independent
    feature_all=feature_names_dep+feature_names_indep
    return dict(zip(index_all,feature_all))#使用两个列表，用zip的方法将两个列表迭代，取出后放入字典当中。

def NGGX_interaction_feature(s):
    sequence=s
    NX=sequence[25]+sequence[27]
    NX_onehot=genera_nucleotide_features(NX,order=2,feature_type="pos_dependent")
#     feat_NX=pandas.concat([feat_NX,NX_onehot],axis=1)
    return NX_onehot
def apply_NGGX_feature(data):
    NGGX_feat=data["30mer"].apply(NGGX_interaction_feature)
    return NGGX_feat
def gc_percent(seq):#利用字符串的count函数来得到序列的GC百分含量
    return (seq.count('G') + seq.count('C'))/float(len(seq))
def countGC_20mer(s, length_audit=True):#利用count函数得到序列中GC的个数
    if length_audit:
        assert len(s) == 30, "seems to assume 30mer"
    return s.count("G")+s.count("C")
def gc_features(data, audit=True):#得到每一条序列的GC个数是否大于10的bool值
    gc_count=data["30mer"].apply(lambda seq:countGC_20mer(seq, audit))#返回的是一个序列，序列可以变成dataframe
    gc_count.name="gc_count"#用来设定序列的label
    gc_above_10=(gc_count>10)*1#直接对series进行操作，返回的是一个Boolean值
    gc_above_10.name="gc_above_10"
    gc_below_10=(gc_count<10)*1
    gc_below_10.name="gc_below_10"
    data["gc_count"]=gc_count
    data["gc_above_10"]= gc_above_10 
    data["gc_below_10"]=gc_below_10
    return gc_above_10, gc_below_10, gc_count
def filter_no_30mer(data):#过滤一下没有30base长度的碱基序列
    data["30mer"]=data["30mer"].apply(lambda x: x[0:30])
    return data
def Tm_feature(data,pam_audit=True):
    segments=[(19,24),(11,19),(6,11)]
    sequence=data["30mer"].values
    featarray=np.ones((sequence.shape[0],4))
    for i,seq in  enumerate(sequence):
        if pam_audit and seq[25:27]!="GG":
            raise Exception("excepted GG but found %s" % seq[25:27])
        rna=True
        featarray[i,0]=Tm.Tm_staluc(seq,rna=rna)#30mer
        featarray[i,1]=Tm.Tm_staluc(seq[segments[0][0]:segments[0][1]], rna=rna) #5nts immediately proximal of the NGG PAM
        featarray[i,2]=Tm.Tm_staluc(seq[segments[1][0]:segments[1][1]], rna=rna)   #8-mer
        featarray[i,3]=Tm.Tm_staluc(seq[segments[2][0]:segments[2][1]], rna=rna)      #5-mer
    feat=pandas.DataFrame(featarray,index=data.index,columns=["Tm global_%s" % rna, "5mer_end_%s" %rna, "8mer_middle_%s" %rna, "5mer_start_%s" %rna])                            
    return feat
def apply_nucleotide_features(seq_data_frame,order,include_pos_independent,prefix=""):#得到有位置独立的和没有位置独立的核酸特征                                                                                                              
    if include_pos_independent:
        feat_pd = seq_data_frame.apply(genera_nucleotide_features, args=(order, prefix, 'pos_dependent'))
        feat_pi = seq_data_frame.apply(genera_nucleotide_features, args=(order, prefix, 'pos_independent'))
        return feat_pd,feat_pi 
    else:
        feat_pd = seq_data_frame.apply(genera_nucleotide_features, args=(order, prefix, 'pos_dependent'))
        return feat_pd
def get_all_order_nuc_features(data,feature_sets,maxorder, max_index_to_use, prefix=""): 
    for order in range(1, maxorder+1):
        nuc_features_pd, nuc_features_pi = apply_nucleotide_features(data, order,prefix=prefix)
        return  nuc_features_pd, nuc_features_pi
def concat_all_need_feat(data):
    ##所有的原始特征都必须是pd类型的
    gc_count=gc_features(filter_no_30mer(data), audit=True)[2]##Series
    gc_above_10=gc_features(filter_no_30mer(data), audit=True)[0]##Series
    gc_below_10=gc_features(filter_no_30mer(data), audit=True)[1]##Series
    pair_base_pd=apply_nucleotide_features(filter_no_30mer(data)["30mer"],order=2,prefix="",include_pos_independent=False)##df
    single_base_pd=apply_nucleotide_features(filter_no_30mer(data)["30mer"],order=1,prefix="",include_pos_independent=False)##df
    pair_base_pi=apply_nucleotide_features(filter_no_30mer(data)["30mer"],order=2,prefix="",include_pos_independent=True)[1]##tuple
#     return pair_base_pi
    single_base_pi=apply_nucleotide_features(filter_no_30mer(data)["30mer"],order=1,prefix="",include_pos_independent=True)[1]##tuple
#     return single_base_pi
#     return type(single_base_pi)
    Tm=Tm_feature(filter_no_30mer(data),pam_audit=True)##df
    NGGX=apply_NGGX_feature(data)
#     return type(Tm)
    all_need_feat=pd.concat([gc_count,gc_above_10,gc_below_10,pair_base_pd,single_base_pd,pair_base_pi,single_base_pi,Tm,NGGX],axis=1)
    return all_need_feat
def get_x_y(all_need_feat,Y):
    y=Y["score_drug_gene rank"]
    vacant=np.zeros((all_need_feat.shape[0],0))
    x=np.array(all_need_feat)
    return x,y
def get_x_y_Deepdata(all_need_feat,Y):
    y=Y["Normalized efficacy"]
    vacant=np.zeros((all_need_feat.shape[0],0))
    x=np.array(all_need_feat)
    return x,y
def get_x_y_maxdata(all_need_feat,Y):
    y=Y["normal_y"]
    vacant=np.zeros((all_need_feat.shape[0],0))
    x=np.array(all_need_feat)
    return x,y



def five_continuous_base(data):
    sequence=data["30mer"].values
    five_con_A=np.zeros(len(sequence))
    five_con_G=np.zeros(len(sequence))
    five_con_C=np.zeros(len(sequence))
    five_con_T=np.zeros(len(sequence))
    for index,seq in enumerate(sequence):
        if "AAAAA" in seq.upper():
            five_con_A[index]=1
        elif "TTTTT" in seq.upper():
            five_con_T[index]=1
        elif "GGGGG" in seq.upper():
            five_con_G[index]=1
        elif "CCCCC" in seq.upper():
            five_con_C[index]=1
    all_continue=np.vstack((five_con_A,five_con_G,five_con_C,five_con_T))
    
    add_five_con=pandas.DataFrame(all_continue.transpose(),index=data.index,columns=["AAAAA", "TTTTT","GGGGG","CCCCC"])
    return add_five_con
#     add_five_con=pd.concat([data,continue_feat],axis=1)

#     return add_five_con
def apply_three_contiu(seq_data_frame,order,include_pos_independent=True,prefix=""):#得到有位置独立的和没有位置独立的核酸特征                                                                                                              
    if include_pos_independent:
        feat_pd_three_contiu = seq_data_frame.apply(genera_nucleotide_features, args=(order, prefix, 'pos_dependent'))
#         return feat_pd
        feat_pi_three_contiu = seq_data_frame.apply(genera_nucleotide_features, args=(order, prefix, 'pos_independent'))
        
        return feat_pd_three_contiu,feat_pi_three_contiu
#     else:
#         feat_pd = seq_data_frame.apply(genera_nucleotide_features, args=(order, prefix, 'pos_dependent'))
#         assert not np.any(np.isnan(feat_pd)), "found nan in feat_pd"
        return feat_pd






def deltaG_20mer(data,dataname="Doench_V1"):#deltaG是直接通过软件计算的
    deltaG_value=[]
    with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/deltaG_data/%s.txt.dG" % dataname,"r") as f2: 
        all_str=f2.read()
        all_list=all_str.split("\n")[1:-1]
        
        deltaG=pd.DataFrame([i.split("\t")[1] for i in all_list],index=data.index)
        deltaG.columns=["DeltaG"]
        return deltaG
def concat_all_need_feat_second(data,dataname="Doench_V1"):#每次改变这里要改
    
    add_five_con=five_continuous_base(data)
    feat_pd_three_contiu=apply_three_contiu(filter_no_30mer(data)["30mer"],order=3,include_pos_independent=True,prefix="")[0]
    feat_pi_three_contiu=apply_three_contiu(filter_no_30mer(data)["30mer"],order=3,include_pos_independent=True,prefix="")[1]
    deltaG_max=deltaG_20mer(data,dataname)
        #exp_type=diff_exp(data,whose)
    all_need_feat_second=pd.concat([concat_all_need_feat(data),deltaG_max,feat_pi_three_contiu,feat_pd_three_contiu,add_five_con],axis=1)
    return all_need_feat_second
def get_x_y_second(all_need_feat,Y):
    y=Y["score_drug_gene rank"]
    x=np.array(all_need_feat_second)
    return x,y
def get_x_y_NB4data_second(all_need_feat,Y):
    y=Y["NB4 CD13"]
    vacant=np.zeros((all_need_feat.shape[0],0))
    x=np.array(all_need_feat)
    return x,y
def get_x_y_max_second(all_need_feat,data):
    y=data["normal_y"]
    
    x=np.array(all_need_feat)
    return x,y
##对Doench的数据加features
data_dict={"NB4":NB4_data}
for dataname in data_dict.keys():
    all_need_feat_second=concat_all_need_feat_second(data_dict[dataname],dataname=dataname)
    #get X
    with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/%s_2488_X.pickle" % dataname,"wb") as f4:
        pickle.dump(all_need_feat_second,f4)
    x=get_x_y_NB4data_second(all_need_feat_second,data_dict[dataname])[0]
    y=get_x_y_NB4data_second(all_need_feat_second,data_dict[dataname])[1]
    with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/%s_input.pickle" % dataname,"wb") as f15:
        pickle.dump(x,f15)
        with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/%s_y.pickle" % dataname,"wb") as f16:
            pickle.dump(y,f16)
# x_2,y_2
#scaler=MinMaxScaler()
#x_2_scalered=scaler.fit_transform(x_2)#这里使用的是去掉量纲数值。





'''

#model train
def extract_spearman_for_fold_deep(metrics,test, y_pred):
    spearman=spearmanr(test, y_pred)[0]
#     assert not np.isnan(spearman), "found nan spearman"
    metrics.append(spearman)
def extract_fpr_tpr_for_fold(aucs,y_binary, test, y_pred):
    assert len(np.unique(y_binary))<=2, "if using AUC need binary targets"
    fpr, tpr, _ = roc_curve(y_binary[test], y_pred)
    roc_auc = auc(fpr, tpr)
    aucs.append(roc_auc)
def get_train_test(x_deep,y_deep,state=0):
    x_deep_train,x_deep_test,y_deep_train,y_deep_test=train_test_split(x_deep,y_deep,random_state=state)
    return x_deep_train,x_deep_test,y_deep_train,y_deep_test
def select_model(x_deep,y_deep,model,state):
    x_deep_train=get_train_test(x_deep,y_deep,state)[0]
    y_deep_train=get_train_test(x_deep,y_deep,state)[2]
    x_deep_test=get_train_test(x_deep,y_deep,state)[1]
    y_deep_test=get_train_test(x_deep,y_deep,state)[3]
    if model== "Ada":
        print("Adaboost with KFold")
        param_grid = {'learning_rate': [0.1, 0.05, 0.01]}
        n_folds=10
        cv = sklearn.cross_validation.KFold(x_deep_train.shape[0], n_folds=n_folds, shuffle=True)#创建随机打乱的index
        metrics=[]
        est = en.GradientBoostingRegressor()
        print("doing the GridSearchCV")
        clf = GridSearchCV(est, param_grid, n_jobs=-1, verbose=1, cv=cv, scoring=spearman_scoring, iid=False)##需要调参
        print("after doing the GridSearchCV")
        clf.fit(x_deep_train,y_deep_train)
        print("after fitting")
        y_pred = clf.predict(x_deep_test)
        extract_spearman_for_fold_deep(metrics,y_deep_test,y_pred)
        return metrics[0]

    elif model== "SVM":
        print("SVM With KFold")
        parameters = {'kernel': ('linear', 'rbf','poly')}
        n_folds=10
        cv = sklearn.cross_validation.KFold(x_deep_train.shape[0], n_folds=n_folds, shuffle=True)#创建随机打乱的index
        metrics=[]
        svc = svm.SVR()
        print("doing the GridSearchCV")
        clf = GridSearchCV(svc, parameters, n_jobs=-1, verbose=1, cv=cv, scoring=spearman_scoring, iid=False)##需要调参
        print("after doing the GridSearchCV")
        clf.fit(x_deep_train,y_deep_train)
        print("after fitting")
        y_pred = clf.predict(x_deep_test)
        extract_spearman_for_fold_deep(metrics,y_deep_test,y_pred)
        return metrics[0]
    elif model=="DT":
        print("DT With KFold")
        parameters = {"max_depth":(1,2,5,10,100,1000)}
        n_folds=10
        cv = sklearn.cross_validation.KFold(x_deep_train.shape[0], n_folds=n_folds, shuffle=True)#创建随机打乱的index
        metrics=[]
        DT = tree.DecisionTreeRegressor(random_state=state)
        print("doing the GridSearchCV")
        clf = GridSearchCV(DT, parameters, n_jobs=-1, verbose=1, cv=cv, scoring=spearman_scoring, iid=False)##需要调参
        print("after doing the GridSearchCV")
        clf.fit(x_deep_train,y_deep_train)
        print("after fitting")
        y_pred = clf.predict(x_deep_test)
        extract_spearman_for_fold_deep(metrics,y_deep_test,y_pred)
        return metrics[0]
    elif model=="linear_model":
        print("linear_model With KFold")
        n_folds=10
        cv = sklearn.cross_validation.KFold(x_deep_train.shape[0], n_folds=n_folds, shuffle=True)#创建随机打乱的index
        metrics=[]
        reg = linear_model.LinearRegression()
        reg.fit(x_deep_train,y_deep_train)
        print("after fitting")
        y_pred = reg.predict(x_deep_test)
        extract_spearman_for_fold_deep(metrics,y_deep_test,y_pred)
        return metrics[0]
    elif model=="Ridge":
        print("Ridge With KFold")
        parameters = {"alpha":(1,3,5,7,9,10)}
        n_folds=10
        cv = sklearn.cross_validation.KFold(x_deep_train.shape[0], n_folds=n_folds, shuffle=True)#创建随机打乱的index
        metrics=[]
        reg = linear_model.Ridge()
        print("doing the GridSearchCV")
        clf = GridSearchCV(reg, parameters, n_jobs=-1, verbose=1, cv=cv, scoring=spearman_scoring, iid=False)##需要调参
        clf.fit(x_deep_train,y_deep_train)
        print("after fitting")
        y_pred = clf.predict(x_deep_test)
        extract_spearman_for_fold_deep(metrics,y_deep_test,y_pred)
        return metrics[0]
    elif model=="Lasso":
        print("Lasso With KFold")
        parameters = {"alpha":(0.1,0.5,0.75,1,10)}
        n_folds=10
        cv = sklearn.cross_validation.KFold(x_deep_train.shape[0], n_folds=n_folds, shuffle=True)#创建随机打乱的index
        metrics=[]
        reg = linear_model.Lasso()
        print("doing the GridSearchCV")
        clf = GridSearchCV(reg, parameters, n_jobs=-1, verbose=1, cv=cv, scoring=spearman_scoring, iid=False)##需要调参
        clf.fit(x_deep_train,y_deep_train)
        print("after fitting")
        y_pred = clf.predict(x_deep_test)
        extract_spearman_for_fold_deep(metrics,y_deep_test,y_pred)
        return metrics[0]
    elif model=="Bayes Ridge":
        print("Bayes Ridge With KFold")
        metrics=[]
        reg = linear_model.BayesianRidge()
        print("doing the GridSearchCV")
        reg.fit(x_deep_train,y_deep_train)
        print("after fitting")
        y_pred = reg.predict(x_deep_test)
        extract_spearman_for_fold_deep(metrics,y_deep_test,y_pred)
        return metrics[0]
    elif model== "RF":
        print("RF With KFold")
        metrics=[]
        rf =RandomForestRegressor()
        print("doing the GridSearchCV")
        rf.fit(x_deep_train,y_deep_train)
        print("after fitting")
        y_pred = rf.predict(x_deep_test)
        extract_spearman_for_fold_deep(metrics,y_deep_test,y_pred)
        return metrics[0]
    elif model == "NN":
        print("NN With KFold")
        metrics=[]
        nn=MLPRegressor(hidden_layer_sizes=[100,100],activation="relu",alpha=1.0,solver="lbfgs")
        nn.fit(x_deep_train,y_deep_train)
        print("after fitting")
        y_pred = nn.predict(x_deep_test)
        extract_spearman_for_fold_deep(metrics,y_deep_test,y_pred)
        return metrics[0]
    

matrix_max_list=[]
model_max_list=[]
#使用max数据：
ada_matrix=select_model(max_Doench_x,max_Doench_y,"Ada",state=0)
svm_matrix=select_model(max_Doench_x,max_Doench_y,"SVM",state=0)
dt_matrix=select_model(max_Doench_x,max_Doench_y,"DT",state=0)
lm_matrix=select_model(max_Doench_x,max_Doench_y,"linear_model",state=0)
ridge_matrix=select_model(max_Doench_x,max_Doench_y,"Ridge",state=0)
lasso_matrix=select_model(max_Doench_x,max_Doench_y,"Lasso",state=0)
br_matrix=select_model(max_Doench_x,max_Doench_y,"Bayes Ridge",state=0)
rf_matrix=select_model(max_Doench_x,max_Doench_y,"RF",state=0)
nn_matrix=select_model(max_Doench_x,max_Doench_y,"NN",state=0)
                      
                      
                      
                      
matrix_max_list.append(ada_matrix)
matrix_max_list.append(svm_matrix)
matrix_max_list.append(dt_matrix)
matrix_max_list.append(lm_matrix)
matrix_max_list.append(ridge_matrix)
matrix_max_list.append(lasso_matrix)
matrix_max_list.append(br_matrix)
matrix_max_list.append(rf_matrix)
matrix_max_list.append(nn_matrix)





model_max_list=["max_ada","max_svm","max_dt","max_lm","max_ridge","max_lasso","max_br","max_rf","max_nn"]
##plot the result
def plot_max_model_metrix(model_max_list,matrix_max_list):    
    plt.figure()
    ax = plt.gca()
    for index,model in enumerate(zip(model_max_list,matrix_max_list)):
        colors=["#00008B","#D14B5D","#006400","#00BFFF","#D8BFD8","#D14B5D","#FF6347","#40E0D0","#EE82EE","#00008B"]
        plt.bar(index+1,matrix_max_list[index],width=0.4,ecolor='k',edgecolor='none',color=colors[index],align='center',label=str(model_max_list[index]))   
    ax.set_xticklabels([" ","Ada","SVM","DT","lm","ridge","lasso","br","rf","nn"],fontsize=10)
    plt.title("R of different model in max normaled add feature data add MEsc Doench filter deltaG")
    ax.set_ylabel('Spearman r', fontsize=10)
    plt.yticks(fontsize=10)
    plt.ylim((0,0.7))
    plt.xticks(np.arange(0,10,1))
    plt.savefig("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/result/normaled_max_data_train_result_add_feature_add_MEsc_Doench_filter_deltaG.pdf")
plot_max_model_metrix(model_max_list,matrix_max_list)

t2 = time.time()
print ("\t\tElapsed time for max train and plot is %.2f seconds" % (t2-t1))

'''

