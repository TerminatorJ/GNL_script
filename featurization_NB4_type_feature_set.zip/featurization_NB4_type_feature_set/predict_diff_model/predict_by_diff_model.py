import pickle
import scipy.stats as st
##get model
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hela_2488.pickle","rb") as f1:
    hela_2488_model=pickle.load(f1)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hct116_hela_2488.pickle","rb") as f2:
    hct116_hela_2488_model=pickle.load(f2)
    
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hela_2029.pickle","rb") as f3:
    hela_2029_model=pickle.load(f3)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hct116_hela_1839.pickle","rb") as f4:
    hct116_hela_1839_model=pickle.load(f4)

with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hela_2701_no_selection.pickle","rb") as f11:
    hela_2701_model=pickle.load(f11)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hct116_hela_2701_no_selection.pickle","rb") as f12:
    hct116_hela_2701_model=pickle.load(f12)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hct116_hela_1163.pickle","rb") as f13:
    hct116_hela_1163_model=pickle.load(f13)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hela_777.pickle","rb") as f15:
    hela_777_model=pickle.load(f15)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hct116_hela_V1_2479_selection.pickle","rb") as f18:
    hct116_hela_V1_2479_model=pickle.load(f18)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/saved_model/hct116_1_hela_V1_datasets_normalized_BR_9_model_80_train.pickle","rb") as f19:
    hct116_hela_V1_2488_model=pickle.load(f19)
#model path

model_path_dir={"hela_2488":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hela_2488.pickle","hela_2029":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hela_2029.pickle","hela_2701":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hela_2701.pickle","hela_777":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hela_777.pickle","hct116_hela_2488":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hct116_hela_2488.pickle","hct116_hela_1839":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hct116_hela_1839.pickle","hct116_hela_2701":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hct116_hela_2701.pickle","hct116_hela_1163":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/use_hela_hct116_to_train_model/feature_selection/compare_diff_model_perforance/saved_model/best_bayes_model_hct116_hela_1163.pickle"}


input_dict={"NB4_2488":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_input_2488.pickle","NB4_2701":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_2701_input.pickle","NB4_1839":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_1839_input","NB4_2029":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_2029_input","NB4_1163":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_1163_input","NB4_777":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_777_input"}




##get input and y
#get input
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_input_2488.pickle","rb") as f5:
    NB4_2488_input=pickle.load(f5)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_2701_input.pickle","rb") as f6:
    NB4_2701_input=pickle.load(f6)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_1839_input","rb") as f9:
    NB4_1839_input=pickle.load(f9)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_2029_input","rb") as f10:
    NB4_2029_input=pickle.load(f10)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_1163_input","rb") as f14:
    NB4_1163_input=pickle.load(f14)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_777_input","rb") as f16:
    NB4_777_input=pickle.load(f16)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_used_columns_2479_input","rb") as f17:
    NB4_2479_input=pickle.load(f17)

#get y
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_y_2488.pickle","rb") as f7:
    NB4_2488_y=pickle.load(f7)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_y_2488.pickle","rb") as f8:
    NB4_2701_y=pickle.load(f8)
with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_input_y/NB4_y_2488.pickle","rb") as f9:
    NB4_y=pickle.load(f9)


##prediction

def spearman_scoring(clf,X, y):
    y_pred = clf.predict(X)
    return st.spearmanr(y_pred, y)[0]



##predcit the 2488

for model_name,model_path in model_path_dir.items():
   # print(model_path)
   # print(model_name)
    feature_num=model_name.split("_")[-1]
    NB4_input_num_list=[str(i) for i in map(lambda x:x.split("_")[1],input_dict.keys())]
    input_index=NB4_input_num_list.index(feature_num)
    NB4_input_path=[j for j in input_dict.values()][input_index]
    model_path_head=model_path.split(".")[0]
    model_path_tail=model_path.split("/")[-1].split(".")[1]
    for inter_num in range(1,11):
        model_inter_path=model_path_head+"_"+str(inter_num)+"."+model_path_tail
    #    print(model_inter_path)
        
        with open(model_inter_path,"rb") as f1:
            this_model=pickle.load(f1)
            with open(NB4_input_path,"rb") as f2:
     #           print(NB4_input_path)
                NB4_input=pickle.load(f2)
                r=spearman_scoring(this_model,NB4_input, NB4_y)
     #           print(r)
                print("the spearman r of %s is: %s" % (model_name,r))
    


'''

print("the spearman correlation of hela_2488:"+str(spearman_scoring(hela_2488_model,NB4_2488_input, NB4_2488_y)))

print("the spearman correlation of hct116_hela_2488:"+str(spearman_scoring(hct116_hela_2488_model,NB4_2488_input, NB4_2488_y)))

##predict the 2701
print("the spearman correlation of hela_2029:"+str(spearman_scoring(hela_2029_model,NB4_2029_input, NB4_2701_y)))

print("the spearman correlation of hct116_hela_1839:"+str(spearman_scoring(hct116_hela_1839_model,NB4_1839_input, NB4_2488_y)))


print("the speaman correlation of hela_2701:"+str(spearman_scoring(hela_2701_model,NB4_2701_input, NB4_2701_y)))
print("the speaman correlation of hela_hct116_2701:"+str(spearman_scoring(hct116_hela_2701_model,NB4_2701_input, NB4_2701_y)))
print("the speaman correlation of hela_hct116_1163:"+str(spearman_scoring(hct116_hela_1163_model,NB4_1163_input, NB4_2701_y)))
print("the speaman correlation of hela_777:"+str(spearman_scoring(hela_777_model,NB4_777_input, NB4_2701_y)))
print("the speaman correlation of hct116_hela_V1_2479:"+str(spearman_scoring(hct116_hela_V1_2479_model,NB4_2479_input, NB4_2701_y)))
print("the speaman correlation of hct116_hela_V1_2488:"+str(spearman_scoring(hct116_hela_V1_2488_model,NB4_2488_input, NB4_2701_y)))

'''
