#-*- encoding:utf8-*-
import pickle

with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/NB4_dataset/NB4.pickle","rb") as f1:
    NB4_data=pickle.load(f1)



#print(ciona_data)
def cal_deltaG(dataname):
    dict={"NB4":NB4_data}
    dataset_20mer=dict[dataname]["30mer"].apply(lambda x : x[4:24])
    list=[]
    for i in dataset_20mer.values:
        list.append(i)
    with open("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/deltaG_data/%s.txt" % dataname,"w") as f14:
        f14.write(";".join(list))

cal_deltaG("NB4")




















