#!/bin/bash
hybrid-ss-min -E "/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/featurization_NB4_type_feature_set/deltaG_data/NB4.txt"

#hybrid-ss-min -E 
