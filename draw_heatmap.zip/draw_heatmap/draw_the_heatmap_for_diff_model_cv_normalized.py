##-*- coding:utf-8 -*-
import pickle
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import scipy.stats as st
##import the best model for diff dataset
#model_path_dict={"ciona":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/ciona_BR_model_80.pickle","Doench_V1":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/Doench_V1_BR_model_80.pickle","Doench_V2":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/Doench_V2_BR_model_80.pickle","Drosophila":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/Drosophila_BR_model.pickle","elegans":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/elegans_BR_model_80.pickle","hct116_1":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/hct116_1_BR_model_80.pickle","hek293t":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/hek293t_BR_model_80.pickle","hela":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/hela_BR_model_80.pickle","hl60":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/hl60_BR_model_80.pickle","MEsc":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/MEsc_BR_model_80.pickle","z_fish_GZ":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/z_fish_GZ_BR_model_80.pickle","z_fish_MM":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/z_fish_MM_BR_model_80.pickle","z_fish_VZ":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/z_fish_VZ_BR_model_80.pickle"}

model_path_dict={"ciona":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/ciona_1_BR_model_80_normalized.pickle","Doench_V1":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/Doench_V1_8_NN_model_80_normalized.pickle","Doench_V2":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/Doench_V2_9_RF_model_80_normalized.pickle","Drosophila":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/Drosophila_1_DT_model_80_normalized.pickle","hct116_1":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/hct116_1_9_BR_model_80_normalized.pickle","hek293t":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/hek293t_10_Ada_model_80_normalized.pickle","hela":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/hela_2_BR_model_80_normalized.pickle","z_fish_GZ":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/z_fish_GZ_8_BR_model_80_normalized.pickle","z_fish_MM":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/z_fish_MM_5_BR_model_80_normalized.pickle","z_fish_VZ":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_model/13_no_normal_model/z_fish_VZ_7_RF_model_80_normalized.pickle"}


#input_dict={"ciona":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/ciona_data_train_data_test_input.pickle",""}

#20% test file
input_dict={"ciona":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/ciona_input_20.pickle","Doench_V1":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Doench_V1_input_20.pickle","Doench_V2":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Doench_V2_input_20.pickle","Drosophila":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Drosophila_input_20.pickle","hct116_1":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hct116_1_input_20.pickle","hek293t":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hek293t_input_20.pickle","hela":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hela_input_20.pickle","z_fish_GZ":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_GZ_input_20.pickle","z_fish_MM":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_MM_input_20.pickle","z_fish_VZ":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_VZ_input_20.pickle"}

y_dict={"ciona":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/ciona_y_20.pickle","Doench_V1":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Doench_V1_y_20.pickle","Doench_V2":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Doench_V2_y_20.pickle","Drosophila":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/Drosophila_y_20.pickle","hct116_1":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hct116_1_y_20.pickle","hek293t":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hek293t_y_20.pickle","hela":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/hela_y_20.pickle","z_fish_GZ":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_GZ_y_20.pickle","z_fish_MM":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_MM_y_20.pickle","z_fish_VZ":"/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_nml_model/all_13_normal_data_input_and_y/z_fish_VZ_y_20.pickle"}




def spearman_scoring(clf,X, y):
    y_pred = clf.predict(X).flatten()
    return sp.stats.spearmanr(y_pred, y.flatten())[0]
def extract_spearman_for_fold(metrics,test,y_pred,row,col):
    spearman=spearmanr(test, y_pred)[0]
    metrics[row,col]=spearman
def spearmanr(x,y):
    r, p = st.spearmanr(x, y)
    return r, p
##draw the heatmap 



def heatmap(data, row_labels, col_labels, ax=None,
            cbar_kw={}, cbarlabel="", **kwargs):
    if not ax:
        ax = plt.gca()

    # Plot the heatmap
    im = ax.imshow(data, **kwargs)

    # Create colorbar
    cbar = ax.figure.colorbar(im, ax=ax, **cbar_kw)
    cbar.ax.set_ylabel(cbarlabel, rotation=-90, va="bottom")

    # We want to show all ticks...
    ax.set_xticks(np.arange(data.shape[1]))
    ax.set_yticks(np.arange(data.shape[0]))
    # ... and label them with the respective list entries.
    ax.set_xticklabels(col_labels)
    ax.set_yticklabels(row_labels)

    # Let the horizontal axes labeling appear on top.
    ax.tick_params(top=True, bottom=False,
                   labeltop=True, labelbottom=False)

    # Rotate the tick labels and set their alignment.
    plt.setp(ax.get_xticklabels(), rotation=-60, ha="right",
             rotation_mode="anchor")

    # Turn spines off and create white grid.
    for edge, spine in ax.spines.items():
        spine.set_visible(False)

    ax.set_xticks(np.arange(data.shape[1]+1)-.5, minor=True)
    ax.set_yticks(np.arange(data.shape[0]+1)-.5, minor=True)
    ax.grid(which="minor", color="w", linestyle='-', linewidth=3)
    ax.tick_params(which="minor", bottom=False, left=False)

    return im,cbar
def annotate_heatmap(im, data=None, valfmt="{x:.2f}",
                     textcolors=["black", "white"],
                     threshold=None, **textkw):
   

    if not isinstance(data, (list, np.ndarray)):
        data = im.get_array()

    # Normalize the threshold to the images color range.
    if threshold is not None:
        threshold = im.norm(threshold)
    else:
        threshold = im.norm(data.max())/2.

    # Set default alignment to center, but allow it to be
    # overwritten by textkw.
    kw = dict(horizontalalignment="center",
              verticalalignment="center")
    kw.update(textkw)

    # Get the formatter in case a string is supplied
    if isinstance(valfmt, str):
        valfmt = matplotlib.ticker.StrMethodFormatter(valfmt)

    # Loop over the data and create a `Text` for each "pixel".
    # Change the text's color depending on the data.
    texts = []
    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            kw.update(color=textcolors[im.norm(data[i, j]) > threshold])
            text = im.axes.text(j, i, valfmt(data[i, j], None), **kw)
            texts.append(text)

    return texts







metrics=np.zeros((10,10))
col=0
'''
for name,model_path in model_path_dict.items():
    with open(model_path,"rb") as f1:
        this_model=pickle.load(f1)
        row=0 
        for input_file,y_file in zip(input_dict.values(),y_dict.values()):
        
            with open(input_file,"rb") as f2:
                this_input=pickle.load(f2)
                with open(y_file,"rb") as f3:
                    this_y=pickle.load(f3)
                   
                    this_y_pred=this_model.predict(this_input)
                    extract_spearman_for_fold(metrics,this_y,this_y_pred,row=row,col=col)
                    row+=1
        col+=1            	
'''
def Get_Average(list):
   sum = 0
   for item in list:
      sum += item
   return sum/len(list)


#spearman_list=[]
for name,model_path in model_path_dict.items():
    row=0
    for input_file,y_file in zip(input_dict.values(),y_dict.values()):
        spearman_list=[]
        with open(input_file,"rb") as f2:
            this_input=pickle.load(f2)
            with open(y_file,"rb") as f3:
                this_y=pickle.load(f3)
                for number in range(1,11):
                    #model_type=model_path.split("/")[-1].split("_")[2]
                    
                    #name=model_path.split("/")[-1].split("_")[0]
                    header="/".join(model_path.split("/")[:-1])+"/"+name
                    model_type=model_path.split("/")[-1].split("_")[-4]
                    tail="model_80_normalized.pickle"
                    new_model_path=header+"_"+str(number)+"_"+model_type+"_"+tail
                    with open(new_model_path,"rb") as f1:
                        this_model=pickle.load(f1)
                        this_y_pred=this_model.predict(this_input)
                        spearman=spearmanr(this_y,this_y_pred)[0]
                        print(spearman)
                        spearman_list.append(spearman)
                spearman_mean=Get_Average(spearman_list)
                #extract_spearman_for_fold(metrics,this_y,this_y_pred,row=row,col=col)
                metrics[row,col]=spearman_mean
                row+=1
    col+=1


print(metrics)













model_name=["ciona_Lasso","Doench_V1_BRR","Doench_V2_RF","Drosophila_RF","hct116_1_BRR","hek293t_Ada","hela_BRR","z_fish_GZ_RF","z_fish_MM_BRR","z_fish_VZ_RF"]
dataset=["ciona(14)","Doench_V1(367)","Doench_V2(695)","Drosophila(8)","hct116_1(848)","hek293t(170)","hela(1621)","z_fish_GZ(19)","z_fish_MM(204)","z_fish_VZ(16)"]
fig, ax = plt.subplots()
print(metrics)
im, cbar = heatmap(metrics, dataset, model_name, ax=ax,
                   cmap="YlOrRd", cbarlabel="spearman r")

fig.tight_layout()
plt.savefig("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_fig/heatmap/%s_of_13_model_13_datasets_20test_no_text_final_cv_normalized.eps" % "heatmap",dpi=300)
texts = annotate_heatmap(im, valfmt="{x:.1f} ")

fig.tight_layout()

plt.savefig("/hwfssz5/ST_LBI/USER/wangjun/CRISPRarray/train_model/train_diff_exp/make_heatmap_of_diff_model_use_normalized_data/saved_fig/heatmap/%s_of_13_model_13_datasets_20test_final_cv_normalized.eps" % "heatmap",dpi=300)
plt.show()




